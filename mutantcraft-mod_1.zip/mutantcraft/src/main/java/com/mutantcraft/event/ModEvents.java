package com.mutantcraft.event;

import com.mutantcraft.capability.MutationCapabilityProvider;
import com.mutantcraft.network.ModPackets;
import com.mutantcraft.network.SyncMutationPacket;
import com.mutantcraft.registry.MutationRegistry;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class ModEvents {

    /**
     * La join world — sincronizăm capability la jucătorul care se alătură.
     */
    @SubscribeEvent
    public static void onEntityJoinWorld(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide) return;
        if (!(event.getEntity() instanceof LivingEntity living)) return;

        living.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(cap -> {
            // Dacă are mutații salvate, le sincronizăm
            if (!cap.getAllMutations().values().stream().allMatch(java.util.List::isEmpty)) {
                ModPackets.sendToNearby(living.level(), living.blockPosition(),
                    new SyncMutationPacket(living.getId(), cap.serializeNBT()));
            }
        });
    }

    /**
     * La login jucător — sincronizăm mutațiile sale.
     */
    @SubscribeEvent
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;

        player.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(cap -> {
            ModPackets.CHANNEL.send(
                net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> player),
                new SyncMutationPacket(player.getId(), cap.serializeNBT())
            );
        });
    }

    /**
     * La death — opțional: șterge mutațiile (poți dezactiva dacă vrei să persiste).
     */
    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        // Dezcommentează dacă vrei ca mutațiile să se piardă la moarte:
        // event.getEntity().getCapability(MutationCapabilityProvider.MUTATION_CAP)
        //     .ifPresent(cap -> cap.clearAll());
    }

    /**
     * La respawn jucător — copiem capability de la corpul vechi.
     */
    @SubscribeEvent
    public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.isEndConquered()) return; // End portal — nu reset
        var newPlayer = event.getEntity();
        var oldPlayer = event.getOriginalPlayer();

        oldPlayer.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(oldCap -> {
            newPlayer.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(newCap -> {
                newCap.deserializeNBT(oldCap.serializeNBT());
            });
        });
    }

    /**
     * La clone jucător (cross-dimension) — copiem capability.
     */
    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        if (!event.isWasDeath()) {
            event.getOriginal().getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(old -> {
                event.getEntity().getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(neo -> {
                    neo.deserializeNBT(old.serializeNBT());
                });
            });
        }
    }

    /**
     * Inițializare registry la server start.
     */
    @SubscribeEvent
    public static void onServerStarting(net.minecraftforge.event.server.ServerStartingEvent event) {
        MutationRegistry.init();
    }
}
