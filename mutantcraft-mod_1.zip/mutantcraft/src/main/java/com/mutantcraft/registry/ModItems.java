package com.mutantcraft.registry;

import com.mutantcraft.MutantCraftMod;
import com.mutantcraft.item.DNAExtractorItem;
import com.mutantcraft.item.MutationResetItem;
import com.mutantcraft.item.SyringeItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
        DeferredRegister.create(ForgeRegistries.ITEMS, MutantCraftMod.MOD_ID);

    public static final RegistryObject<Item> SYRINGE = ITEMS.register("syringe",
        () -> new SyringeItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> DNA_EXTRACTOR = ITEMS.register("dna_extractor",
        () -> new DNAExtractorItem(new Item.Properties().stacksTo(1).durability(64)));

    public static final RegistryObject<Item> MUTATION_RESET_SERUM = ITEMS.register("mutation_reset_serum",
        () -> new MutationResetItem(new Item.Properties().stacksTo(8)));
}
