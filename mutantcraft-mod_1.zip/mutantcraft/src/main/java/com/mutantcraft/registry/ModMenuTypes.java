package com.mutantcraft.registry;

import com.mutantcraft.MutantCraftMod;
import com.mutantcraft.gui.MutatorMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModMenuTypes {

    public static final DeferredRegister<MenuType<?>> MENU_TYPES =
        DeferredRegister.create(ForgeRegistries.MENU_TYPES, MutantCraftMod.MOD_ID);

    public static final RegistryObject<MenuType<MutatorMenu>> MUTATOR_MENU =
        MENU_TYPES.register("mutator_menu",
            () -> IForgeMenuType.create((windowId, inv, data) ->
                new MutatorMenu(windowId, inv, data)));
}
