package com.mutantcraft.registry;

import com.mutantcraft.ability.MutationPart;
import com.mutantcraft.capability.IMutationCapability.PartSlot;
import com.mutantcraft.capability.IMutationCapability.SpecialAbility;

import java.util.*;

/**
 * Registrul central al tuturor MutationPart-urilor.
 * Adaugă mutații noi cu registerPart().
 */
public class MutationRegistry {

    private static final Map<String, MutationPart> REGISTRY = new LinkedHashMap<>();

    // === Înregistrare la startup ===
    public static void init() {

        // ───── HEAD ─────
        register(new MutationPart.Builder("zombie_head")
            .name("Zombie Head").slot(PartSlot.HEAD).source("minecraft:zombie")
            .damage(1.5f).health(2f)
            .abilities(SpecialAbility.NIGHT_VISION)
            .describe("Vede în întuneric.", "Muscat de zombi la atac.")
            .rarity(1).build());

        register(new MutationPart.Builder("creeper_head")
            .name("Creeper Head").slot(PartSlot.HEAD).source("minecraft:creeper")
            .damage(5f)
            .abilities(SpecialAbility.EXPLODE)
            .describe("Explozie la atac corp-la-corp.", "Cooldown: 30s.")
            .rarity(3).build());

        register(new MutationPart.Builder("enderman_head")
            .name("Enderman Head").slot(PartSlot.HEAD).source("minecraft:enderman")
            .damage(2f)
            .abilities(SpecialAbility.TELEPORT, SpecialAbility.NIGHT_VISION)
            .describe("Teleportare scurtă la hit.", "Vede în întuneric.")
            .rarity(3).build());

        register(new MutationPart.Builder("blaze_head")
            .name("Blaze Head").slot(PartSlot.HEAD).source("minecraft:blaze")
            .damage(3f)
            .abilities(SpecialAbility.FIRE_IMMUNE)
            .describe("Imun la foc și lavă.", "Aprinde țintele la atac.")
            .rarity(2).build());

        register(new MutationPart.Builder("spider_head")
            .name("Spider Head").slot(PartSlot.HEAD).source("minecraft:spider")
            .damage(1f)
            .abilities(SpecialAbility.NIGHT_VISION, SpecialAbility.POISON_TOUCH)
            .describe("Otrăvește la mușcătură.", "Vede în întuneric.")
            .rarity(2).build());

        // ───── ARMS ─────
        register(new MutationPart.Builder("iron_golem_arms")
            .name("Iron Golem Arms").slot(PartSlot.ARMS).source("minecraft:iron_golem")
            .damage(8f).health(4f)
            .describe("Lovituri masive.", "+8 damage base.")
            .rarity(4).build());

        register(new MutationPart.Builder("zombie_arms")
            .name("Zombie Arms").slot(PartSlot.ARMS).source("minecraft:zombie")
            .damage(2f)
            .describe("Putere de zombie.", "Bazic dar stabil.")
            .rarity(1).build());

        register(new MutationPart.Builder("wither_skeleton_arms")
            .name("Wither Skeleton Arms").slot(PartSlot.ARMS).source("minecraft:wither_skeleton")
            .damage(4f)
            .abilities(SpecialAbility.WITHER_TOUCH)
            .describe("Aplică Wither la fiecare hit.", "Stack cu alte arms pentru mai mult damage.")
            .rarity(3).build());

        register(new MutationPart.Builder("witch_arms")
            .name("Witch Arms").slot(PartSlot.ARMS).source("minecraft:witch")
            .damage(1f)
            .abilities(SpecialAbility.POISON_TOUCH, SpecialAbility.REGEN)
            .describe("Otravă la atac.", "Regenerare pasivă.")
            .rarity(2).build());

        // ───── LEGS ─────
        register(new MutationPart.Builder("horse_legs")
            .name("Horse Legs").slot(PartSlot.LEGS).source("minecraft:horse")
            .speed(0.15f).jump(0.3f)
            .describe("+15% viteză de mișcare.", "+30% înălțime săritură.")
            .rarity(2).build());

        register(new MutationPart.Builder("spider_legs")
            .name("Spider Legs").slot(PartSlot.LEGS).source("minecraft:spider")
            .speed(0.1f).jump(0.1f)
            .abilities(SpecialAbility.SPIDER_CLIMB)
            .describe("Cățărare pe pereți verticali.", "Viteză ușor crescută.")
            .rarity(3).build());

        register(new MutationPart.Builder("iron_golem_legs")
            .name("Iron Golem Legs").slot(PartSlot.LEGS).source("minecraft:iron_golem")
            .speed(-0.05f).health(6f)
            .abilities(SpecialAbility.KNOCKBACK_IMMUNE)
            .describe("Imun la knockback.", "+6 HP, ușor mai lent.")
            .rarity(3).build());

        register(new MutationPart.Builder("rabbit_legs")
            .name("Rabbit Legs").slot(PartSlot.LEGS).source("minecraft:rabbit")
            .speed(0.08f).jump(0.5f)
            .describe("+50% înălțime săritură.", "Salturi rapide.")
            .rarity(1).build());

        // ───── PASSIVE ─────
        register(new MutationPart.Builder("phantom_wings")
            .name("Phantom Wings").slot(PartSlot.PASSIVE).source("minecraft:phantom")
            .health(-2f)
            .abilities(SpecialAbility.FLY)
            .describe("Zbor activ (ține Space).", "-2 HP maxim.")
            .rarity(4).build());

        register(new MutationPart.Builder("enderman_passive")
            .name("Enderman Essence").slot(PartSlot.PASSIVE).source("minecraft:enderman")
            .abilities(SpecialAbility.TELEPORT, SpecialAbility.WATER_BREATH)
            .describe("Teleportare la damage luat.", "Imun la ploaie.")
            .rarity(3).build());

        register(new MutationPart.Builder("drowned_gills")
            .name("Drowned Gills").slot(PartSlot.PASSIVE).source("minecraft:drowned")
            .abilities(SpecialAbility.WATER_BREATH)
            .describe("Respirație infinită sub apă.", "Viteză crescută în apă.")
            .rarity(2).build());

        register(new MutationPart.Builder("witch_brew")
            .name("Witch Brew").slot(PartSlot.PASSIVE).source("minecraft:witch")
            .health(4f)
            .abilities(SpecialAbility.REGEN)
            .describe("Regenerare lentă pasivă.", "+4 HP maxim.")
            .rarity(2).build());
    }

    public static void register(MutationPart part) {
        REGISTRY.put(part.getId(), part);
    }

    public static MutationPart getById(String id) {
        return REGISTRY.get(id);
    }

    public static Collection<MutationPart> getAll() {
        return REGISTRY.values();
    }

    public static List<MutationPart> getBySlot(PartSlot slot) {
        return REGISTRY.values().stream()
            .filter(p -> p.getSlot() == slot)
            .toList();
    }
}
