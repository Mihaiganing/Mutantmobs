package com.mutantcraft.ability;

import com.mutantcraft.capability.IMutationCapability;
import com.mutantcraft.capability.IMutationCapability.SpecialAbility;
import com.mutantcraft.capability.MutationCapabilityProvider;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Motorul principal de abilități.
 * Ascultă evenimente Forge și aplică efectele mutațiilor.
 */
@Mod.EventBusSubscriber
public class AbilityEngine {

    // UUID-uri fixe pentru AttributeModifier (nu se duplică)
    private static final UUID DAMAGE_UUID = UUID.fromString("a1b2c3d4-e5f6-7890-abcd-ef1234567890");
    private static final UUID SPEED_UUID  = UUID.fromString("b2c3d4e5-f6a7-8901-bcde-f12345678901");
    private static final UUID HEALTH_UUID = UUID.fromString("c3d4e5f6-a7b8-9012-cdef-123456789012");
    private static final UUID JUMP_UUID   = UUID.fromString("d4e5f6a7-b8c9-0123-def0-234567890123");

    // Cooldowns per-entitate (UUID entitate → map abilitate → tick countdown)
    private static final Map<java.util.UUID, Map<SpecialAbility, Integer>> COOLDOWNS = new HashMap<>();

    // ===================================================
    // TICK — aplicare efecte pasive și stats
    // ===================================================

    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide) return;

        entity.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(cap -> {
            applyStats(entity, cap);
            applyPassiveAbilities(entity, cap);
            tickCooldowns(entity);
        });
    }

    private static void applyStats(LivingEntity entity, IMutationCapability cap) {
        // Damage
        var dmgAttr = entity.getAttribute(Attributes.ATTACK_DAMAGE);
        if (dmgAttr != null) {
            dmgAttr.removeModifier(DAMAGE_UUID);
            float bonus = cap.getTotalDamageBonus();
            if (bonus != 0) {
                dmgAttr.addPermanentModifier(new AttributeModifier(
                    DAMAGE_UUID, "mutantcraft_damage", bonus, AttributeModifier.Operation.ADDITION));
            }
        }

        // Speed
        var speedAttr = entity.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speedAttr != null) {
            speedAttr.removeModifier(SPEED_UUID);
            float sBonus = cap.getTotalSpeedBonus();
            if (sBonus != 0) {
                speedAttr.addPermanentModifier(new AttributeModifier(
                    SPEED_UUID, "mutantcraft_speed", sBonus, AttributeModifier.Operation.ADDITION));
            }
        }

        // Max HP
        var hpAttr = entity.getAttribute(Attributes.MAX_HEALTH);
        if (hpAttr != null) {
            hpAttr.removeModifier(HEALTH_UUID);
            float hBonus = cap.getAllMutations().values().stream()
                .flatMap(java.util.List::stream)
                .map(MutationPart::getHealthBonus)
                .reduce(0f, Float::sum);
            if (hBonus != 0) {
                hpAttr.addPermanentModifier(new AttributeModifier(
                    HEALTH_UUID, "mutantcraft_health", hBonus, AttributeModifier.Operation.ADDITION));
            }
        }
    }

    private static void applyPassiveAbilities(LivingEntity entity, IMutationCapability cap) {
        // Zbor (Phantom Wings)
        if (cap.hasAbility(SpecialAbility.FLY)) {
            // Activat când entitatea apasă Space (implementare client-side în KeyHandler)
        }

        // Water breathing
        if (cap.hasAbility(SpecialAbility.WATER_BREATH)) {
            entity.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 40, 0, false, false));
        }

        // Night vision
        if (cap.hasAbility(SpecialAbility.NIGHT_VISION)) {
            entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 40, 0, false, false));
        }

        // Fire immunity
        if (cap.hasAbility(SpecialAbility.FIRE_IMMUNE)) {
            entity.clearFire();
        }

        // Regenerare
        if (cap.hasAbility(SpecialAbility.REGEN)) {
            if (entity.tickCount % 60 == 0) {
                entity.heal(0.5f);
            }
        }

        // Spider climb — setat flag în entity
        if (cap.hasAbility(SpecialAbility.SPIDER_CLIMB)) {
            // În MixinLivingEntity suprascriem canClimb()
        }
    }

    // ===================================================
    // LA ATAC — abilități active la hit
    // ===================================================

    @SubscribeEvent
    public static void onLivingAttack(LivingAttackEvent event) {
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker)) return;
        if (attacker.level().isClientSide) return;

        attacker.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(cap -> {

            // Creeper head — explozie
            if (cap.hasAbility(SpecialAbility.EXPLODE) && !onCooldown(attacker, SpecialAbility.EXPLODE)) {
                attacker.level().explode(attacker, event.getEntity().getX(),
                    event.getEntity().getY(), event.getEntity().getZ(),
                    2.0f, net.minecraft.world.level.Level.ExplosionInteraction.NONE);
                setCooldown(attacker, SpecialAbility.EXPLODE, 600); // 30s
            }

            // Enderman — teleport
            if (cap.hasAbility(SpecialAbility.TELEPORT) && !onCooldown(attacker, SpecialAbility.TELEPORT)) {
                // Teleport mic aleatoriu
                for (int i = 0; i < 16; i++) {
                    double tx = attacker.getX() + (attacker.getRandom().nextDouble() - 0.5) * 8;
                    double ty = attacker.getY() + (attacker.getRandom().nextInt(3) - 1);
                    double tz = attacker.getZ() + (attacker.getRandom().nextDouble() - 0.5) * 8;
                    if (attacker.randomTeleport(tx, ty, tz, true)) break;
                }
                setCooldown(attacker, SpecialAbility.TELEPORT, 100); // 5s
            }
        });
    }

    // ===================================================
    // LA DAMAGE PRIMIT — abilități reactive
    // ===================================================

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide) return;

        entity.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(cap -> {

            // Poison touch — aplicat la victimă
            if (cap.hasAbility(SpecialAbility.POISON_TOUCH)) {
                if (event.getSource().getEntity() instanceof LivingEntity) {
                    entity.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0));
                }
            }

            // Wither touch
            if (cap.hasAbility(SpecialAbility.WITHER_TOUCH)) {
                if (event.getSource().getEntity() instanceof LivingEntity) {
                    entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 0));
                }
            }

            // Knockback immune
            if (cap.hasAbility(SpecialAbility.KNOCKBACK_IMMUNE)) {
                event.setAmount(event.getAmount() * 0.5f);
                // knockback gestionat în MixinLivingEntity
            }

            // Enderman — teleport defensiv la damage
            if (cap.hasAbility(SpecialAbility.TELEPORT) && !onCooldown(entity, SpecialAbility.TELEPORT)) {
                for (int i = 0; i < 8; i++) {
                    double tx = entity.getX() + (entity.getRandom().nextDouble() - 0.5) * 6;
                    double ty = entity.getY();
                    double tz = entity.getZ() + (entity.getRandom().nextDouble() - 0.5) * 6;
                    if (entity.randomTeleport(tx, ty, tz, true)) break;
                }
                setCooldown(entity, SpecialAbility.TELEPORT, 60);
            }
        });
    }

    // ===================================================
    // Cooldown helpers
    // ===================================================

    private static void tickCooldowns(LivingEntity entity) {
        Map<SpecialAbility, Integer> map = COOLDOWNS.get(entity.getUUID());
        if (map == null) return;
        map.replaceAll((ability, ticks) -> Math.max(0, ticks - 1));
        map.entrySet().removeIf(e -> e.getValue() == 0);
        if (map.isEmpty()) COOLDOWNS.remove(entity.getUUID());
    }

    private static boolean onCooldown(LivingEntity entity, SpecialAbility ability) {
        Map<SpecialAbility, Integer> map = COOLDOWNS.get(entity.getUUID());
        return map != null && map.getOrDefault(ability, 0) > 0;
    }

    private static void setCooldown(LivingEntity entity, SpecialAbility ability, int ticks) {
        COOLDOWNS.computeIfAbsent(entity.getUUID(), k -> new HashMap<>()).put(ability, ticks);
    }
}
