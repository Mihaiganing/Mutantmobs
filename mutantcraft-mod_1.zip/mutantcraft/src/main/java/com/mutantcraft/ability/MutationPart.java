package com.mutantcraft.ability;

import com.mutantcraft.capability.IMutationCapability.PartSlot;
import com.mutantcraft.capability.IMutationCapability.SpecialAbility;

import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * O "parte" de mutație extrasă dintr-un mob specific.
 * De ex: "Zombie Head" → slot HEAD, damage +2, abilitate NIGHT_VISION
 */
public class MutationPart {

    private final String id;
    private final String displayName;
    private final PartSlot slot;
    private final String sourceMobType;   // ex: "minecraft:zombie"

    // Stats
    private final float damageBonus;
    private final float speedBonus;
    private final float jumpBonus;
    private final float healthBonus;

    // Abilități speciale
    private final Set<SpecialAbility> abilities;

    // Descriere pentru tooltip GUI
    private final List<String> description;

    // Rarity (1=common, 2=uncommon, 3=rare, 4=epic)
    private final int rarity;

    public MutationPart(Builder builder) {
        this.id = builder.id;
        this.displayName = builder.displayName;
        this.slot = builder.slot;
        this.sourceMobType = builder.sourceMobType;
        this.damageBonus = builder.damageBonus;
        this.speedBonus = builder.speedBonus;
        this.jumpBonus = builder.jumpBonus;
        this.healthBonus = builder.healthBonus;
        this.abilities = Collections.unmodifiableSet(builder.abilities);
        this.description = Collections.unmodifiableList(builder.description);
        this.rarity = builder.rarity;
    }

    // === Getteri ===
    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public PartSlot getSlot() { return slot; }
    public String getSourceMobType() { return sourceMobType; }
    public float getDamageBonus() { return damageBonus; }
    public float getSpeedBonus() { return speedBonus; }
    public float getJumpBonus() { return jumpBonus; }
    public float getHealthBonus() { return healthBonus; }
    public Set<SpecialAbility> getAbilities() { return abilities; }
    public List<String> getDescription() { return description; }
    public int getRarity() { return rarity; }

    // === Builder pattern ===
    public static class Builder {
        private final String id;
        private String displayName = "Unknown Part";
        private PartSlot slot = PartSlot.PASSIVE;
        private String sourceMobType = "unknown";
        private float damageBonus = 0f;
        private float speedBonus = 0f;
        private float jumpBonus = 0f;
        private float healthBonus = 0f;
        private Set<SpecialAbility> abilities = Collections.emptySet();
        private List<String> description = Collections.emptyList();
        private int rarity = 1;

        public Builder(String id) { this.id = id; }
        public Builder name(String name) { this.displayName = name; return this; }
        public Builder slot(PartSlot slot) { this.slot = slot; return this; }
        public Builder source(String mob) { this.sourceMobType = mob; return this; }
        public Builder damage(float v) { this.damageBonus = v; return this; }
        public Builder speed(float v) { this.speedBonus = v; return this; }
        public Builder jump(float v) { this.jumpBonus = v; return this; }
        public Builder health(float v) { this.healthBonus = v; return this; }
        public Builder abilities(SpecialAbility... abs) {
            this.abilities = Set.of(abs); return this;
        }
        public Builder describe(String... lines) {
            this.description = List.of(lines); return this;
        }
        public Builder rarity(int r) { this.rarity = r; return this; }
        public MutationPart build() { return new MutationPart(this); }
    }
}
