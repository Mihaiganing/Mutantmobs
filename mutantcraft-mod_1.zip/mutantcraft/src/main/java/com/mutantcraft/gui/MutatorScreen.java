package com.mutantcraft.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mutantcraft.ability.MutationPart;
import com.mutantcraft.capability.IMutationCapability.PartSlot;
import com.mutantcraft.registry.MutationRegistry;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

import java.util.List;

/**
 * GUI principal al Mutatorului.
 *
 * Layout:
 * ┌────────────────────────────────────────────┐
 * │  [HEAD slots x3]  [ARMS slots x3]          │
 * │  [LEGS slots x3]  [PASSIVE slots x3]       │
 * │                                            │
 * │  ← Panel stânga: lista tuturor parts       │
 * │  → Panel dreapta: slot-urile active        │
 * │                                            │
 * │  [APPLY]  [RESET]  Tooltip hover           │
 * └────────────────────────────────────────────┘
 */
public class MutatorScreen extends AbstractContainerScreen<MutatorMenu> {

    private static final ResourceLocation BG =
        new ResourceLocation("mutantcraft", "textures/gui/mutator.png");

    // Dimensiuni GUI
    private static final int GUI_W = 380;
    private static final int GUI_H = 240;

    // Panel stânga (lista parts disponibile)
    private static final int LIST_X = 8;
    private static final int LIST_Y = 30;
    private static final int LIST_W = 140;
    private static final int LIST_H = 180;
    private static final int ENTRY_H = 18;

    // Panel dreapta (slots active)
    private static final int SLOTS_X = 160;
    private static final int SLOTS_Y = 20;

    // Scrolling pentru lista de parts
    private int scrollOffset = 0;
    private int maxVisible;

    // Dragging
    private MutationPart dragging = null;
    private int dragX, dragY;

    // Hover tooltip
    private MutationPart hoveredPart = null;
    private PartSlot hoveredSlot = null;

    // Filtrare pe slot
    private PartSlot filterSlot = null;

    public MutatorScreen(MutatorMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = GUI_W;
        this.imageHeight = GUI_H;
        this.maxVisible = LIST_H / ENTRY_H;
    }

    @Override
    protected void renderBg(GuiGraphics gfx, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;

        // Background principal
        gfx.fill(x, y, x + GUI_W, y + GUI_H, 0xFF1A1A2E);
        gfx.fill(x + 1, y + 1, x + GUI_W - 1, y + GUI_H - 1, 0xFF16213E);

        // Titlu
        gfx.drawString(font, "§6Mutator — " + getTargetName(), x + 8, y + 8, 0xFFFFFF, false);

        // Separator vertical
        gfx.fill(x + 152, y + 20, x + 154, y + GUI_H - 10, 0xFF0F3460);

        // Panel lista parts
        renderPartsList(gfx, x, y, mouseX, mouseY);

        // Panel slots
        renderSlotPanels(gfx, x, y, mouseX, mouseY);

        // Butoane
        renderButtons(gfx, x, y, mouseX, mouseY);

        // Item în drag
        if (dragging != null) {
            renderPartEntry(gfx, dragX - 40, dragY - 9, dragging, true, false);
        }
    }

    private void renderPartsList(GuiGraphics gfx, int x, int y, int mx, int my) {
        // Background lista
        gfx.fill(x + LIST_X, y + LIST_Y - 2, x + LIST_X + LIST_W, y + LIST_Y + LIST_H, 0xFF0D1B2A);

        // Header filtre slot
        int fx = x + LIST_X;
        int fy = y + 20;
        renderFilterButton(gfx, fx,      fy, "ALL",     filterSlot == null, mx, my);
        renderFilterButton(gfx, fx + 28, fy, "H",       filterSlot == PartSlot.HEAD, mx, my);
        renderFilterButton(gfx, fx + 56, fy, "A",       filterSlot == PartSlot.ARMS, mx, my);
        renderFilterButton(gfx, fx + 84, fy, "L",       filterSlot == PartSlot.LEGS, mx, my);
        renderFilterButton(gfx, fx + 112,fy, "P",       filterSlot == PartSlot.PASSIVE, mx, my);

        // Lista parts
        List<MutationPart> parts = getFilteredParts();
        int visibleCount = Math.min(maxVisible, parts.size() - scrollOffset);
        hoveredPart = null;

        for (int i = 0; i < visibleCount; i++) {
            MutationPart part = parts.get(scrollOffset + i);
            int ey = y + LIST_Y + i * ENTRY_H;
            boolean hovered = mx >= x + LIST_X && mx < x + LIST_X + LIST_W
                && my >= ey && my < ey + ENTRY_H;
            if (hovered) hoveredPart = part;
            renderPartEntry(gfx, x + LIST_X, ey, part, false, hovered);
        }

        // Scrollbar
        if (parts.size() > maxVisible) {
            int sbH = (int)((float) maxVisible / parts.size() * LIST_H);
            int sbY = (int)((float) scrollOffset / parts.size() * LIST_H);
            gfx.fill(x + LIST_X + LIST_W - 3, y + LIST_Y + sbY,
                     x + LIST_X + LIST_W,     y + LIST_Y + sbY + sbH, 0xFF4A4E69);
        }
    }

    private void renderFilterButton(GuiGraphics gfx, int x, int y, String label,
                                     boolean active, int mx, int my) {
        int color = active ? 0xFF4A90D9 : 0xFF2A3A5A;
        gfx.fill(x, y, x + 24, y + 10, color);
        gfx.drawString(font, label, x + 2, y + 1, active ? 0xFFFFFF : 0xAAAAAA, false);
    }

    private void renderPartEntry(GuiGraphics gfx, int x, int y, MutationPart part,
                                  boolean dragging, boolean hovered) {
        int bg = hovered ? 0xFF2A4A6A : 0xFF1A2A3A;
        if (dragging) bg = 0xFF3A6A9A;
        gfx.fill(x, y, x + LIST_W - 4, y + ENTRY_H - 2, bg);

        // Culoare rarity
        int nameColor = switch (part.getRarity()) {
            case 2 -> 0x55FF55;
            case 3 -> 0x5555FF;
            case 4 -> 0xAA00AA;
            default -> 0xFFFFFF;
        };

        // Slot indicator
        String slotIcon = switch (part.getSlot()) {
            case HEAD -> "§e[H]";
            case ARMS -> "§c[A]";
            case LEGS -> "§a[L]";
            case PASSIVE -> "§b[P]";
        };

        gfx.drawString(font, slotIcon, x + 2, y + 4, 0xFFFFFF, false);
        gfx.drawString(font, part.getDisplayName(), x + 22, y + 4, nameColor, false);
    }

    private void renderSlotPanels(GuiGraphics gfx, int x, int y, int mx, int my) {
        int col = 0;
        int row = 0;
        for (PartSlot slot : PartSlot.values()) {
            int px = x + SLOTS_X + col * 105;
            int py = y + SLOTS_Y + row * 100;
            renderSlotPanel(gfx, px, py, slot, mx, my);
            col++;
            if (col >= 2) { col = 0; row++; }
        }
    }

    private void renderSlotPanel(GuiGraphics gfx, int x, int y, PartSlot slot, int mx, int my) {
        String label = switch (slot) {
            case HEAD -> "§e⬡ CAP";
            case ARMS -> "§c⚔ BRATE";
            case LEGS -> "§a⚡ PICIOARE";
            case PASSIVE -> "§b✦ PASIV";
        };

        gfx.fill(x, y, x + 100, y + 90, 0xFF0D1B2A);
        gfx.fill(x, y, x + 100, y + 12, 0xFF0F3460);
        gfx.drawString(font, label, x + 3, y + 2, 0xFFFFFF, false);

        List<MutationPart> parts = menu.getPendingForSlot(slot);

        for (int i = 0; i < slot.getMaxStacks(); i++) {
            int sy = y + 14 + i * 22;
            boolean filled = i < parts.size();
            gfx.fill(x + 2, sy, x + 98, sy + 20, filled ? 0xFF1A3A5A : 0xFF0A1A2A);

            if (filled) {
                MutationPart part = parts.get(i);
                boolean hovered = mx >= x + 2 && mx < x + 98 && my >= sy && my < sy + 20;
                if (hovered) { hoveredPart = part; hoveredSlot = slot; }
                int nameColor = switch (part.getRarity()) {
                    case 2 -> 0x55FF55; case 3 -> 0x5555FF; case 4 -> 0xAA00AA; default -> 0xFFFFFF;
                };
                // Truncate lung nume
                String name = part.getDisplayName().length() > 12
                    ? part.getDisplayName().substring(0, 11) + "…"
                    : part.getDisplayName();
                gfx.drawString(font, name, x + 4, sy + 6, nameColor, false);
                // X pentru remove
                gfx.drawString(font, "§c✕", x + 88, sy + 6, 0xFF0000, false);
            } else {
                gfx.drawString(font, "§8+ slot gol", x + 4, sy + 6, 0x888888, false);
            }
        }

        // Drop zone indicator dacă dragging
        if (dragging != null) {
            boolean canDrop = dragging.getSlot() == slot
                && parts.size() < slot.getMaxStacks();
            if (canDrop) {
                gfx.fill(x, y, x + 100, y + 90, 0x4400FF00);
            }
        }
    }

    private void renderButtons(GuiGraphics gfx, int x, int y, int mx, int my) {
        int bY = y + GUI_H - 22;

        // Apply
        boolean applyHov = mx >= x + SLOTS_X && mx < x + SLOTS_X + 70 && my >= bY && my < bY + 14;
        gfx.fill(x + SLOTS_X, bY, x + SLOTS_X + 70, bY + 14, applyHov ? 0xFF2ECC71 : 0xFF27AE60);
        gfx.drawCenteredString(font, "§0Aplică", x + SLOTS_X + 35, bY + 3, 0xFFFFFF);

        // Reset
        boolean resetHov = mx >= x + SLOTS_X + 78 && mx < x + SLOTS_X + 148 && my >= bY && my < bY + 14;
        gfx.fill(x + SLOTS_X + 78, bY, x + SLOTS_X + 148, bY + 14, resetHov ? 0xFFE74C3C : 0xFFC0392B);
        gfx.drawCenteredString(font, "§0Reset", x + SLOTS_X + 113, bY + 3, 0xFFFFFF);
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(gfx);
        super.render(gfx, mouseX, mouseY, partialTick);

        // Tooltip hover
        if (hoveredPart != null) {
            renderPartTooltip(gfx, hoveredPart, mouseX, mouseY);
        }
    }

    private void renderPartTooltip(GuiGraphics gfx, MutationPart part, int mx, int my) {
        List<net.minecraft.network.chat.Component> lines = new java.util.ArrayList<>();
        lines.add(Component.literal("§6" + part.getDisplayName()));
        lines.add(Component.literal("§7Slot: " + part.getSlot().name()));
        lines.add(Component.literal("§7Sursă: §e" + part.getSourceMobType()));
        if (part.getDamageBonus() != 0)
            lines.add(Component.literal("§cDamage: §f+" + part.getDamageBonus()));
        if (part.getSpeedBonus() != 0)
            lines.add(Component.literal("§aViteză: §f+" + (int)(part.getSpeedBonus()*100) + "%"));
        if (part.getJumpBonus() != 0)
            lines.add(Component.literal("§aSăritură: §f+" + (int)(part.getJumpBonus()*100) + "%"));
        if (part.getHealthBonus() != 0)
            lines.add(Component.literal("§cHP: §f+" + part.getHealthBonus()));
        if (!part.getAbilities().isEmpty()) {
            lines.add(Component.literal("§bAbilități:"));
            part.getAbilities().forEach(a ->
                lines.add(Component.literal("  §b• " + a.name())));
        }
        part.getDescription().forEach(d ->
            lines.add(Component.literal("§8" + d)));
        gfx.renderComponentTooltip(font, lines, mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int x = leftPos, y = topPos;

        // Click pe lista parts → start drag
        List<MutationPart> parts = getFilteredParts();
        if (mx >= x + LIST_X && mx < x + LIST_X + LIST_W
            && my >= y + LIST_Y && my < y + LIST_Y + LIST_H) {
            int idx = (int)((my - y - LIST_Y) / ENTRY_H) + scrollOffset;
            if (idx >= 0 && idx < parts.size()) {
                dragging = parts.get(idx);
                dragX = (int) mx;
                dragY = (int) my;
                return true;
            }
        }

        // Click pe X în slot → remove
        int col = 0, row = 0;
        for (PartSlot slot : PartSlot.values()) {
            int px = x + SLOTS_X + col * 105;
            int py = y + SLOTS_Y + row * 100;
            List<MutationPart> slotParts = menu.getPendingForSlot(slot);
            for (int i = 0; i < slotParts.size(); i++) {
                int sy = py + 14 + i * 22;
                if (mx >= px + 86 && mx < px + 98 && my >= sy && my < sy + 20) {
                    menu.removePendingPart(slot, slotParts.get(i));
                    return true;
                }
            }
            col++; if (col >= 2) { col = 0; row++; }
        }

        // Click filtre
        int fx = x + LIST_X, fy = y + 20;
        if (my >= fy && my < fy + 10) {
            if (mx >= fx && mx < fx + 24)       { filterSlot = null; return true; }
            if (mx >= fx+28 && mx < fx+52)      { filterSlot = PartSlot.HEAD; return true; }
            if (mx >= fx+56 && mx < fx+80)      { filterSlot = PartSlot.ARMS; return true; }
            if (mx >= fx+84 && mx < fx+108)     { filterSlot = PartSlot.LEGS; return true; }
            if (mx >= fx+112 && mx < fx+136)    { filterSlot = PartSlot.PASSIVE; return true; }
        }

        // Butoane Apply / Reset
        int bY = y + GUI_H - 22;
        if (my >= bY && my < bY + 14) {
            if (mx >= x + SLOTS_X && mx < x + SLOTS_X + 70) {
                menu.applyMutations();
                this.onClose();
                return true;
            }
            if (mx >= x + SLOTS_X + 78 && mx < x + SLOTS_X + 148) {
                menu.resetPending();
                return true;
            }
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            // Verifică dacă e dropped pe un slot panel
            int col = 0, row = 0;
            for (PartSlot slot : PartSlot.values()) {
                int px = leftPos + SLOTS_X + col * 105;
                int py = topPos + SLOTS_Y + row * 100;
                if (mx >= px && mx < px + 100 && my >= py && my < py + 90) {
                    if (dragging.getSlot() == slot) {
                        boolean added = menu.addPendingPart(slot, dragging);
                        if (!added) {
                            // Slot plin — feedback vizual
                        }
                    }
                    break;
                }
                col++; if (col >= 2) { col = 0; row++; }
            }
            dragging = null;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            dragX = (int) mx;
            dragY = (int) my;
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        List<MutationPart> parts = getFilteredParts();
        int maxScroll = Math.max(0, parts.size() - maxVisible);
        scrollOffset = (int) Math.max(0, Math.min(maxScroll, scrollOffset - delta));
        return true;
    }

    @Override
    protected void renderLabels(GuiGraphics gfx, int mx, int my) {
        // Nu desenăm label-urile vanilla (titlu + inventory)
    }

    private List<MutationPart> getFilteredParts() {
        if (filterSlot == null) return new java.util.ArrayList<>(MutationRegistry.getAll());
        return MutationRegistry.getBySlot(filterSlot);
    }

    private String getTargetName() {
        MutatorMenu m = this.menu;
        if (m.getTarget() != null) return m.getTarget().getDisplayName().getString();
        return "Mob";
    }
}
