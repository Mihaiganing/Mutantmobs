package com.mutantcraft.gui;

import com.mutantcraft.ability.MutationPart;
import com.mutantcraft.capability.IMutationCapability;
import com.mutantcraft.capability.IMutationCapability.PartSlot;
import com.mutantcraft.capability.MutationCapabilityProvider;
import com.mutantcraft.network.ApplyMutationPacket;
import com.mutantcraft.network.ModPackets;
import com.mutantcraft.registry.ModMenuTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;

import java.util.*;

/**
 * Container logic pentru GUI mutator.
 * Nu folosim slot-uri vanilla — toată logica e custom în MutatorScreen.
 */
public class MutatorMenu extends AbstractContainerMenu {

    private final LivingEntity target;
    private final int targetId;

    // State local (copiat din capability)
    private final Map<PartSlot, List<MutationPart>> pendingMutations = new EnumMap<>(PartSlot.class);

    public MutatorMenu(int windowId, Inventory inv, LivingEntity target) {
        super(ModMenuTypes.MUTATOR_MENU.get(), windowId);
        this.target = target;
        this.targetId = target.getId();

        // Inițializăm pending cu mutațiile existente
        for (PartSlot slot : PartSlot.values()) {
            pendingMutations.put(slot, new ArrayList<>());
        }

        target.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(cap -> {
            for (PartSlot slot : PartSlot.values()) {
                pendingMutations.get(slot).addAll(cap.getPartsForSlot(slot));
            }
        });
    }

    // Constructor pentru client-side (din network)
    public MutatorMenu(int windowId, Inventory inv, net.minecraft.network.FriendlyByteBuf buf) {
        super(ModMenuTypes.MUTATOR_MENU.get(), windowId);
        this.targetId = buf.readInt();
        // target va fi rezolvat pe client din world entity list
        this.target = null;
        for (PartSlot slot : PartSlot.values()) {
            pendingMutations.put(slot, new ArrayList<>());
        }
    }

    public boolean addPendingPart(PartSlot slot, MutationPart part) {
        List<MutationPart> list = pendingMutations.get(slot);
        if (list.size() >= slot.getMaxStacks()) return false;
        if (part.getSlot() != slot) return false;
        list.add(part);
        return true;
    }

    public boolean removePendingPart(PartSlot slot, MutationPart part) {
        return pendingMutations.get(slot).remove(part);
    }

    public List<MutationPart> getPendingForSlot(PartSlot slot) {
        return Collections.unmodifiableList(pendingMutations.get(slot));
    }

    public Map<PartSlot, List<MutationPart>> getAllPending() {
        return Collections.unmodifiableMap(pendingMutations);
    }

    /** Trimite mutațiile pending la server pentru aplicare. */
    public void applyMutations() {
        ModPackets.CHANNEL.sendToServer(new ApplyMutationPacket(targetId, pendingMutations));
    }

    /** Reset pending la starea originală. */
    public void resetPending() {
        for (PartSlot slot : PartSlot.values()) {
            pendingMutations.get(slot).clear();
        }
        if (target != null) {
            target.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(cap -> {
                for (PartSlot slot : PartSlot.values()) {
                    pendingMutations.get(slot).addAll(cap.getPartsForSlot(slot));
                }
            });
        }
    }

    public int getTargetId() { return targetId; }
    public LivingEntity getTarget() { return target; }

    @Override
    public boolean stillValid(Player player) {
        return true; // Verificare distanță dacă vrei
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY; // Nu folosim slot-uri vanilla
    }
}
