package com.mutantcraft.gui;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import org.jetbrains.annotations.Nullable;

public class MutatorMenuProvider implements MenuProvider {

    private final LivingEntity target;

    public MutatorMenuProvider(LivingEntity target) {
        this.target = target;
    }

    @Override
    public Component getDisplayName() {
        return Component.literal("Mutator — " + target.getDisplayName().getString());
    }

    @Override
    public @Nullable AbstractContainerMenu createMenu(int windowId, Inventory inv, Player player) {
        return new MutatorMenu(windowId, inv, target);
    }

    // Serializare pentru network (trimite entity ID la client)
    public void writeToBuffer(FriendlyByteBuf buf) {
        buf.writeInt(target.getId());
    }
}
