package com.mutantcraft.capability;

import com.mutantcraft.ability.MutationPart;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;

import java.util.*;

public class MutationCapabilityImpl implements IMutationCapability {

    private final Map<PartSlot, List<MutationPart>> mutations = new EnumMap<>(PartSlot.class);
    private boolean dirty = false;

    public MutationCapabilityImpl() {
        for (PartSlot slot : PartSlot.values()) {
            mutations.put(slot, new ArrayList<>());
        }
    }

    @Override
    public List<MutationPart> getPartsForSlot(PartSlot slot) {
        return Collections.unmodifiableList(mutations.get(slot));
    }

    @Override
    public boolean addPart(PartSlot slot, MutationPart part) {
        List<MutationPart> list = mutations.get(slot);
        if (list.size() >= slot.getMaxStacks()) return false;
        // Verificăm dacă e compatibil cu slot-ul
        if (part.getSlot() != slot) return false;
        list.add(part);
        dirty = true;
        return true;
    }

    @Override
    public boolean removePart(PartSlot slot, MutationPart part) {
        boolean removed = mutations.get(slot).remove(part);
        if (removed) dirty = true;
        return removed;
    }

    @Override
    public void clearSlot(PartSlot slot) {
        mutations.get(slot).clear();
        dirty = true;
    }

    @Override
    public void clearAll() {
        mutations.values().forEach(List::clear);
        dirty = true;
    }

    @Override
    public Map<PartSlot, List<MutationPart>> getAllMutations() {
        return Collections.unmodifiableMap(mutations);
    }

    // === Stats calculate cu stacking diminishing ===

    @Override
    public float getTotalDamageBonus() {
        List<MutationPart> arms = mutations.get(PartSlot.ARMS);
        return (float) applyDiminishingReturns(
            arms.stream().mapToDouble(MutationPart::getDamageBonus).sum()
        );
    }

    @Override
    public float getTotalSpeedBonus() {
        List<MutationPart> legs = mutations.get(PartSlot.LEGS);
        return (float) applyDiminishingReturns(
            legs.stream().mapToDouble(MutationPart::getSpeedBonus).sum()
        );
    }

    @Override
    public float getTotalJumpBonus() {
        List<MutationPart> legs = mutations.get(PartSlot.LEGS);
        return (float) applyDiminishingReturns(
            legs.stream().mapToDouble(MutationPart::getJumpBonus).sum()
        );
    }

    /**
     * Fiecare stack adaugă mai puțin decât cel precedent.
     * Formula: total = base * (1 + 0.7 + 0.5) pentru 3 stacks
     */
    private double applyDiminishingReturns(double rawTotal) {
        return rawTotal * 0.75; // simplificat; poți rafina per-stack
    }

    @Override
    public boolean hasAbility(SpecialAbility ability) {
        // Caută în toate slot-urile
        for (List<MutationPart> parts : mutations.values()) {
            for (MutationPart part : parts) {
                if (part.getAbilities().contains(ability)) return true;
            }
        }
        return false;
    }

    // === NBT Serialization ===

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        for (PartSlot slot : PartSlot.values()) {
            ListTag listTag = new ListTag();
            for (MutationPart part : mutations.get(slot)) {
                listTag.add(StringTag.valueOf(part.getId()));
            }
            tag.put(slot.name(), listTag);
        }
        return tag;
    }

    @Override
    public void deserializeNBT(CompoundTag tag) {
        for (PartSlot slot : PartSlot.values()) {
            mutations.get(slot).clear();
            if (tag.contains(slot.name(), Tag.TAG_LIST)) {
                ListTag listTag = tag.getList(slot.name(), Tag.TAG_STRING);
                for (int i = 0; i < listTag.size(); i++) {
                    String id = listTag.getString(i);
                    MutationPart part = com.mutantcraft.registry.MutationRegistry.getById(id);
                    if (part != null) {
                        mutations.get(slot).add(part);
                    }
                }
            }
        }
        dirty = false;
    }

    @Override
    public boolean isDirty() { return dirty; }

    @Override
    public void setDirty(boolean dirty) { this.dirty = dirty; }
}
