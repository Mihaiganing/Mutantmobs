package com.mutantcraft.capability;

import com.mutantcraft.ability.MutationPart;
import net.minecraft.nbt.CompoundTag;

import java.util.List;
import java.util.Map;

/**
 * Capability principală — stochează toate mutațiile unui mob.
 * Fiecare slot (HEAD, ARMS, LEGS, PASSIVE) poate conține până la 3 parts stacked.
 */
public interface IMutationCapability {

    // === Getteri / setteri pentru slots ===

    List<MutationPart> getPartsForSlot(PartSlot slot);

    boolean addPart(PartSlot slot, MutationPart part);

    boolean removePart(PartSlot slot, MutationPart part);

    void clearSlot(PartSlot slot);

    void clearAll();

    Map<PartSlot, List<MutationPart>> getAllMutations();

    // === Stats dinamice calculate ===

    float getTotalDamageBonus();       // din ARMS
    float getTotalSpeedBonus();        // din LEGS
    float getTotalJumpBonus();         // din LEGS
    boolean hasAbility(SpecialAbility ability); // din PASSIVE / HEAD

    // === Serialization (pentru save/load) ===

    CompoundTag serializeNBT();
    void deserializeNBT(CompoundTag tag);

    // === Dirty flag (pentru network sync) ===

    boolean isDirty();
    void setDirty(boolean dirty);

    // =========================================

    enum PartSlot {
        HEAD, ARMS, LEGS, PASSIVE;

        public int getMaxStacks() { return 3; }
    }

    enum SpecialAbility {
        FLY,           // Creeper wings / Phantom
        INVISIBILITY,  // Spider eyes passive
        FIRE_IMMUNE,   // Blaze torso
        WATER_BREATH,  // Drowned gills
        EXPLODE,       // Creeper head — activat la atac
        SPIDER_CLIMB,  // Spider legs
        TELEPORT,      // Enderman passive
        POISON_TOUCH,  // Witch hands
        WITHER_TOUCH,  // Wither skeleton arms
        REGEN,         // Witch passive
        NIGHT_VISION,  // Enderman/Spider head
        KNOCKBACK_IMMUNE // Iron Golem legs
    }
}
