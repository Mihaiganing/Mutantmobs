package com.mutantcraft;

import com.mutantcraft.capability.MutationCapabilityProvider;
import com.mutantcraft.event.ModEvents;
import com.mutantcraft.network.ModPackets;
import com.mutantcraft.registry.ModItems;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MutantCraftMod.MOD_ID)
public class MutantCraftMod {

    public static final String MOD_ID = "mutantcraft";

    public MutantCraftMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.ITEMS.register(modBus);

        modBus.addListener(this::commonSetup);
        modBus.addListener(this::registerCapabilities);

        MinecraftForge.EVENT_BUS.register(ModEvents.class);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModPackets::register);
    }

    private void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.register(com.mutantcraft.capability.IMutationCapability.class);
    }

    // Atașează capability la orice LivingEntity
    @net.minecraftforge.eventbus.api.SubscribeEvent
    public static void attachCapabilities(AttachCapabilitiesEvent<net.minecraft.world.entity.Entity> event) {
        if (event.getObject() instanceof LivingEntity living) {
            if (!living.getCapability(MutationCapabilityProvider.MUTATION_CAP).isPresent()) {
                event.addCapability(
                    new ResourceLocation(MOD_ID, "mutation"),
                    new MutationCapabilityProvider()
                );
            }
        }
    }
}
