package com.mutantcraft.network;

import com.mutantcraft.MutantCraftMod;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModPackets {

    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(MutantCraftMod.MOD_ID, "main"),
        () -> PROTOCOL,
        PROTOCOL::equals,
        PROTOCOL::equals
    );

    private static int id = 0;

    public static void register() {
        CHANNEL.registerMessage(id++,
            SyncMutationPacket.class,
            SyncMutationPacket::encode,
            SyncMutationPacket::decode,
            SyncMutationPacket::handle,
            java.util.Optional.of(NetworkDirection.PLAY_TO_CLIENT)
        );

        CHANNEL.registerMessage(id++,
            ApplyMutationPacket.class,
            ApplyMutationPacket::encode,
            ApplyMutationPacket::decode,
            ApplyMutationPacket::handle,
            java.util.Optional.of(NetworkDirection.PLAY_TO_SERVER)
        );
    }

    /** Trimite un pachet la toți jucătorii aproape de o poziție. */
    public static void sendToNearby(Level level, BlockPos pos, Object packet) {
        if (level instanceof ServerLevel serverLevel) {
            CHANNEL.send(
                PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(
                    pos.getX(), pos.getY(), pos.getZ(), 64, serverLevel.dimension())),
                packet
            );
        }
    }
}
