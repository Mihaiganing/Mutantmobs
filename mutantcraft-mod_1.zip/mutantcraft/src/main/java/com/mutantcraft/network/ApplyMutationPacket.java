package com.mutantcraft.network;

import com.mutantcraft.ability.MutationPart;
import com.mutantcraft.capability.IMutationCapability.PartSlot;
import com.mutantcraft.capability.MutationCapabilityProvider;
import com.mutantcraft.registry.MutationRegistry;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.*;
import java.util.function.Supplier;

/**
 * Client → Server: aplică mutațiile pending pe un mob.
 */
public class ApplyMutationPacket {

    private final int entityId;
    private final Map<PartSlot, List<String>> partIds; // slot → lista de ID-uri

    public ApplyMutationPacket(int entityId, Map<PartSlot, List<MutationPart>> mutations) {
        this.entityId = entityId;
        this.partIds = new EnumMap<>(PartSlot.class);
        for (var entry : mutations.entrySet()) {
            List<String> ids = entry.getValue().stream()
                .map(MutationPart::getId).toList();
            this.partIds.put(entry.getKey(), ids);
        }
    }

    private ApplyMutationPacket(int entityId, Map<PartSlot, List<String>> ids, boolean internal) {
        this.entityId = entityId;
        this.partIds = ids;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(entityId);
        buf.writeInt(partIds.size());
        for (var entry : partIds.entrySet()) {
            buf.writeEnum(entry.getKey());
            buf.writeInt(entry.getValue().size());
            entry.getValue().forEach(buf::writeUtf);
        }
    }

    public static ApplyMutationPacket decode(FriendlyByteBuf buf) {
        int id = buf.readInt();
        int slotCount = buf.readInt();
        Map<PartSlot, List<String>> map = new EnumMap<>(PartSlot.class);
        for (int i = 0; i < slotCount; i++) {
            PartSlot slot = buf.readEnum(PartSlot.class);
            int count = buf.readInt();
            List<String> ids = new ArrayList<>();
            for (int j = 0; j < count; j++) ids.add(buf.readUtf());
            map.put(slot, ids);
        }
        return new ApplyMutationPacket(id, map, true);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            var sender = ctx.get().getSender();
            if (sender == null) return;

            ServerLevel level = sender.serverLevel();
            Entity entity = level.getEntity(entityId);
            if (!(entity instanceof LivingEntity living)) return;

            // Validare: jucătorul trebuie să fie în raza de 10 blocuri
            if (sender.distanceTo(living) > 10.0) return;

            living.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(cap -> {
                cap.clearAll();
                for (var entry : partIds.entrySet()) {
                    for (String partId : entry.getValue()) {
                        MutationPart part = MutationRegistry.getById(partId);
                        if (part != null) cap.addPart(entry.getKey(), part);
                    }
                }
                cap.setDirty(false);

                // Sync la toți jucătorii din raza de 64 blocuri
                ModPackets.CHANNEL.send(
                    PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(
                        living.getX(), living.getY(), living.getZ(), 64, level.dimension())),
                    new SyncMutationPacket(entityId, cap.serializeNBT())
                );
            });
        });
        ctx.get().setPacketHandled(true);
    }
}
