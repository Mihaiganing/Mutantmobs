package com.mutantcraft.network;

import com.mutantcraft.capability.MutationCapabilityProvider;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server → Client: sincronizează mutațiile unui mob după modificare.
 */
public class SyncMutationPacket {

    private final int entityId;
    private final CompoundTag mutationData;

    public SyncMutationPacket(int entityId, CompoundTag data) {
        this.entityId = entityId;
        this.mutationData = data;
    }

    // Encoder
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(entityId);
        buf.writeNbt(mutationData);
    }

    // Decoder (factory)
    public static SyncMutationPacket decode(FriendlyByteBuf buf) {
        int id = buf.readInt();
        CompoundTag tag = buf.readNbt();
        return new SyncMutationPacket(id, tag);
    }

    // Handler — executat pe client
    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) return;

            Entity entity = mc.level.getEntity(entityId);
            if (entity instanceof LivingEntity living) {
                living.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(cap -> {
                    cap.deserializeNBT(mutationData);
                });
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
