package com.mutantcraft.item;

import com.mutantcraft.ability.MutationPart;
import com.mutantcraft.registry.MutationRegistry;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * DNA Extractor — click dreapta pe un mob (sau cadavru în 5s) pentru a extrage un MutationPart.
 * Rezultatul este stocat ca NBT pe un item "DNA Fragment" virtual (ItemStack cu tag).
 * Durabilitate limitată (64 utilizări).
 */
public class DNAExtractorItem extends Item {

    public DNAExtractorItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player,
                                                   LivingEntity target, InteractionHand hand) {
        if (player.level().isClientSide) return InteractionResult.SUCCESS;

        String mobType = target.getType().getDescriptionId(); // ex: "entity.minecraft.zombie"
        String mobId = net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE
            .getKey(target.getType()).toString(); // ex: "minecraft:zombie"

        // Caută toate parts disponibile pentru acest mob
        List<MutationPart> available = MutationRegistry.getAll().stream()
            .filter(p -> p.getSourceMobType().equals(mobId))
            .toList();

        if (available.isEmpty()) {
            player.sendSystemMessage(Component.literal("§cAcest mob nu are parts de extras."));
            return InteractionResult.FAIL;
        }

        // Alege random o parte (cu șansă bazată pe rarity)
        MutationPart chosen = pickRandomPart(available, target.getRandom());

        // Creează un ItemStack de "DNA Fragment" cu NBT
        ItemStack fragment = createDNAFragment(chosen);
        if (!player.addItem(fragment)) {
            player.drop(fragment, false);
        }

        player.sendSystemMessage(Component.literal(
            "§aExtras: §e" + chosen.getDisplayName() + " §7(" + rarityName(chosen.getRarity()) + ")"
        ));

        // Uzează extractorul
        stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));

        return InteractionResult.CONSUME;
    }

    private MutationPart pickRandomPart(List<MutationPart> parts, net.minecraft.util.RandomSource rand) {
        // Parts mai rare au șanse mai mici (rarity 4 = 10%, rarity 1 = 70%)
        int totalWeight = parts.stream().mapToInt(p -> 5 - p.getRarity()).sum();
        int roll = rand.nextInt(Math.max(totalWeight, 1));
        int acc = 0;
        for (MutationPart part : parts) {
            acc += (5 - part.getRarity());
            if (roll < acc) return part;
        }
        return parts.get(0);
    }

    public static ItemStack createDNAFragment(MutationPart part) {
        // Folosim seringa ca item vizual, cu NBT custom
        ItemStack stack = new ItemStack(com.mutantcraft.registry.ModItems.SYRINGE.get());
        CompoundTag tag = stack.getOrCreateTag();
        tag.putString("dna_part_id", part.getId());
        tag.putString("dna_display", part.getDisplayName());
        stack.setHoverName(Component.literal("§bDNA: " + part.getDisplayName()));
        return stack;
    }

    public static @Nullable String getDNAPartId(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        if (tag != null && tag.contains("dna_part_id")) {
            return tag.getString("dna_part_id");
        }
        return null;
    }

    private String rarityName(int r) {
        return switch (r) {
            case 1 -> "§fCommon";
            case 2 -> "§aUncommon";
            case 3 -> "§9Rare";
            case 4 -> "§5Epic";
            default -> "§7Unknown";
        };
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                 List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7Click dreapta pe un mob pentru a extrage DNA."));
        tooltip.add(Component.literal("§764 utilizări. Parts mai rare = șansă mai mică."));
    }
}
