package com.mutantcraft.item;

import com.mutantcraft.capability.MutationCapabilityProvider;
import com.mutantcraft.gui.MutatorMenuProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Seringa de mutație — click dreapta pe un mob pentru a deschide GUI-ul de mutare.
 * Click dreapta în gol → deschide GUI pentru player.
 */
public class SyringeItem extends Item {

    public SyringeItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player,
                                                   LivingEntity target, InteractionHand hand) {
        if (player.level().isClientSide) return InteractionResult.SUCCESS;

        // Deschide GUI de mutație pentru target
        target.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(cap -> {
            player.openMenu(new MutatorMenuProvider(target));
        });

        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                 List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7Click dreapta pe un mob pentru a-l muta."));
        tooltip.add(Component.literal("§7Click dreapta în gol → mutezi pe tine."));
    }
}
