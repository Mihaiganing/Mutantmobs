package com.mutantcraft.item;

import com.mutantcraft.capability.MutationCapabilityProvider;
import com.mutantcraft.network.ModPackets;
import com.mutantcraft.network.SyncMutationPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class MutationResetItem extends Item {

    public MutationResetItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player,
                                                   LivingEntity target, InteractionHand hand) {
        if (player.level().isClientSide) return InteractionResult.SUCCESS;

        target.getCapability(MutationCapabilityProvider.MUTATION_CAP).ifPresent(cap -> {
            cap.clearAll();
            cap.setDirty(true);
            ModPackets.sendToNearby(target.level(), target.blockPosition(),
                new SyncMutationPacket(target.getId(), cap.serializeNBT()));
            player.sendSystemMessage(Component.literal("§aMutațiile au fost resetate."));
        });

        stack.shrink(1);
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                 List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7Șterge toate mutațiile unui mob."));
        tooltip.add(Component.literal("§cIreversibil!"));
    }
}
