# MutantCraft Mod — 1.21.1 Forge

Mod care îți permite să creezi mutanți combinând parts de la orice mob din Minecraft.

---

## Instalare & Build

### Cerințe
- Java 21
- Forge MDK 1.21.1-47.3.0 (descarcă de pe https://files.minecraftforge.net)

### Pași
1. Dezarhivează MDK-ul Forge într-un folder
2. Copiază folderul `src/` din acest proiect în folderul MDK
3. Copiază `build.gradle` din acest proiect (înlocuiește cel din MDK)
4. Rulează în terminal:
   ```
   ./gradlew genEclipseRuns   (sau genIntellijRuns)
   ./gradlew build
   ```
5. JAR-ul se generează în `build/libs/`

---

## Cum funcționează

### Iteme

| Item | Crafting | Utilizare |
|------|----------|-----------|
| **Mutation Syringe** | 2x Glass Pane + Stick | Click dreapta pe mob → deschide GUI |
| **DNA Extractor** | Iron + Glass + Stick | Click dreapta pe mob → extrage un MutationPart |
| **Mutation Reset Serum** | Glass Bottle + Water + Nether Star | Șterge toate mutațiile unui mob |

### GUI Mutator
- **Panel stânga**: lista tuturor parts disponibile (filtrare pe slot)
- **Panel dreapta**: 4 slot-uri (HEAD, ARMS, LEGS, PASSIVE), câte 3 stacks fiecare
- **Drag & Drop**: trage un part din lista stânga pe slot-ul potrivit
- **X**: click pe ✕ pentru a scoate un part din slot
- **Apply**: trimite mutațiile la server și le aplică mobului
- **Reset**: anulează modificările pending

### Slots & Parts

#### HEAD (max 3 stacks)
| Part | Sursă | Bonus | Abilitate |
|------|-------|-------|-----------|
| Zombie Head | Zombie | +1.5 DMG, +2 HP | Night Vision |
| Creeper Head | Creeper | +5 DMG | Explozie la atac (30s CD) |
| Enderman Head | Enderman | +2 DMG | Teleport + Night Vision |
| Blaze Head | Blaze | +3 DMG | Fire Immune |
| Spider Head | Spider | +1 DMG | Night Vision + Poison |

#### ARMS (max 3 stacks)
| Part | Sursă | Bonus | Abilitate |
|------|-------|-------|-----------|
| Iron Golem Arms | Iron Golem | +8 DMG, +4 HP | — |
| Zombie Arms | Zombie | +2 DMG | — |
| Wither Skeleton Arms | Wither Skeleton | +4 DMG | Wither la hit |
| Witch Arms | Witch | +1 DMG | Poison + Regen |

#### LEGS (max 3 stacks)
| Part | Sursă | Bonus | Abilitate |
|------|-------|-------|-----------|
| Horse Legs | Horse | +15% Speed, +30% Jump | — |
| Spider Legs | Spider | +10% Speed | Wall Climb |
| Iron Golem Legs | Iron Golem | +6 HP, -5% Speed | Knockback Immune |
| Rabbit Legs | Rabbit | +8% Speed, +50% Jump | — |

#### PASSIVE (max 3 stacks)
| Part | Sursă | Abilitate |
|------|-------|-----------|
| Phantom Wings | Phantom | Zbor (ține Space) |
| Enderman Essence | Enderman | Teleport la damage + Water Immune |
| Drowned Gills | Drowned | Water Breathing + viteză în apă |
| Witch Brew | Witch | Regen pasiv + 4 HP |

### Sistem de Stacking
- Fiecare slot acceptă până la **3 parts** (pot fi aceeași sau diferite)
- Stats-urile se acumulează cu **diminishing returns** (al 2-lea stack = 75% eficiență)
- Abilitățile nu se stacking — prezența o singură dată e suficientă

### Adăugare Parts Noi
În `MutationRegistry.java`, adaugă:
```java
register(new MutationPart.Builder("my_part_id")
    .name("My Custom Part")
    .slot(PartSlot.HEAD)          // HEAD / ARMS / LEGS / PASSIVE
    .source("minecraft:zombie")   // mob entity ID
    .damage(3f)
    .speed(0.1f)
    .jump(0.2f)
    .health(5f)
    .abilities(SpecialAbility.FIRE_IMMUNE)
    .describe("Descriere linie 1", "Descriere linie 2")
    .rarity(2)                    // 1=Common, 2=Uncommon, 3=Rare, 4=Epic
    .build());
```

---

## Structura proiectului

```
src/main/java/com/mutantcraft/
├── MutantCraftMod.java              # Clasa principală
├── ability/
│   ├── AbilityEngine.java           # Motor abilități (Forge events)
│   └── MutationPart.java            # Definția unei parts
├── capability/
│   ├── IMutationCapability.java     # Interface capability
│   ├── MutationCapabilityImpl.java  # Implementare
│   └── MutationCapabilityProvider.java
├── event/
│   ├── ModEvents.java               # Server events
│   └── ClientEvents.java            # Client events + screen registration
├── gui/
│   ├── MutatorMenu.java             # Container logic
│   ├── MutatorMenuProvider.java     # Menu provider
│   └── MutatorScreen.java           # GUI vizual
├── item/
│   ├── SyringeItem.java
│   ├── DNAExtractorItem.java
│   └── MutationResetItem.java
├── network/
│   ├── ModPackets.java              # Canal Forge network
│   ├── SyncMutationPacket.java      # Server → Client
│   └── ApplyMutationPacket.java     # Client → Server
└── registry/
    ├── ModItems.java
    ├── ModMenuTypes.java
    └── MutationRegistry.java        # Toate parts înregistrate
```
